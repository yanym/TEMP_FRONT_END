import React, { Component } from 'react';
import './App.css';
import Showtime from './components/Showtime';

class App extends Component {
  render() {
    return (
      <div>
        <Showtime />
      </div>
    );
  }
}

export default App;